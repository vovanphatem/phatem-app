import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import NavBar from "@/components/NavBar";
import Link from "next/link";
import { COST_PER_CREDIT } from "@/lib/vietqr";

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("credits, is_admin, full_name")
    .eq("id", user.id)
    .single();

  return (
    <>
      <NavBar initialCredits={profile?.credits ?? 0} isAdmin={!!profile?.is_admin} />
      <main className="max-w-4xl mx-auto px-4 pb-16">
        <div className="card mb-4">
          <h2 className="text-lg font-bold mb-2">Xin chào, {profile?.full_name || user.email} 👋</h2>
          <p style={{ color: "var(--sub)" }}>
            Bạn hiện có <b style={{ color: "var(--pink)" }}>{profile?.credits ?? 0} lượt</b> tạo QR.
          </p>
          <div className="flex gap-3 flex-wrap mt-4">
            <Link href="/create" className="btn">⚡ Tạo QR ngay</Link>
            <Link href="/topup" className="btn-outline">💜 Nạp thêm lượt</Link>
          </div>
        </div>
        <div className="card">
          <h2 className="text-lg font-bold mb-3">Cách hoạt động</h2>
          {[
            ["1. Chọn mẫu QR", "Ở trang \"Tạo QR\""],
            ["2. Điền ngân hàng, số tài khoản, tên", "Tự sinh mã VietQR chuẩn"],
            ["3. Bấm \"Tạo QR\"", "Trừ 1 lượt / lần"],
            ["4. Hết lượt?", `Nạp ở trang "Nạp lượt" — ${COST_PER_CREDIT.toLocaleString("vi-VN")}đ/lượt`],
          ].map(([a, b]) => (
            <div key={a} className="flex justify-between py-2 text-sm" style={{ borderBottom: "1px dashed var(--line)" }}>
              <span style={{ color: "var(--sub)" }}>{a}</span>
              <b>{b}</b>
            </div>
          ))}
        </div>
      </main>
    </>
  );
}
