"use client";
import { useEffect, useState, useCallback } from "react";
import NavBar from "@/components/NavBar";
import { createClient } from "@/lib/supabase/client";

type Bill = { id: string; user_id: string; credits_requested: number; amount_vnd: number; note: string; status: string; created_at: string };
type Profile = { id: string; email: string; full_name: string; credits: number; is_admin: boolean; created_at: string };

const STATUS_LABEL: Record<string, string> = { pending: "Chờ duyệt", approved: "Đã duyệt", rejected: "Từ chối" };

export default function AdminPage() {
  const supabase = createClient();
  const [ready, setReady] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [credits, setCredits] = useState(0);
  const [pending, setPending] = useState<Bill[]>([]);
  const [allBills, setAllBills] = useState<Bill[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [namesById, setNamesById] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<string | null>(null);

  const loadAll = useCallback(async () => {
    const { data: allUsers } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });
    setUsers(allUsers ?? []);
    const map: Record<string, string> = {};
    (allUsers ?? []).forEach((u) => (map[u.id] = u.full_name || u.email));
    setNamesById(map);

    const { data: bills } = await supabase.from("bills").select("*").order("created_at", { ascending: false });
    setAllBills(bills ?? []);
    setPending((bills ?? []).filter((b) => b.status === "pending"));
  }, [supabase]);

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const { data: profile } = await supabase.from("profiles").select("credits, is_admin").eq("id", data.user.id).single();
      setCredits(profile?.credits ?? 0);
      setIsAdmin(!!profile?.is_admin);
      setReady(true);
      if (profile?.is_admin) loadAll();
    });
  }, [supabase, loadAll]);

  async function approve(id: string) {
    const { error } = await supabase.rpc("approve_bill", { p_bill_id: id });
    setMsg(error ? "Lỗi: " + error.message : "Đã duyệt ✔");
    loadAll();
  }
  async function reject(id: string) {
    const { error } = await supabase.rpc("reject_bill", { p_bill_id: id });
    setMsg(error ? "Lỗi: " + error.message : "Đã từ chối");
    loadAll();
  }
  async function addCredits(id: string) {
    const { error } = await supabase.rpc("admin_add_credits", { p_user_id: id, p_amount: 10 });
    setMsg(error ? "Lỗi: " + error.message : "Đã cộng 10 lượt");
    loadAll();
  }

  if (!ready) return null;

  return (
    <>
      <NavBar initialCredits={credits} isAdmin={isAdmin} />
      <main className="max-w-4xl mx-auto px-4 pb-16">
        {!isAdmin ? (
          <div className="card">
            <h2 className="text-lg font-bold mb-2">Không có quyền truy cập</h2>
            <p style={{ color: "var(--sub)" }}>
              Tài khoản này chưa được cấp quyền admin. Chạy lệnh SQL sau trong Supabase (đổi email của bạn):
            </p>
            <pre className="mt-3 p-3 rounded-lg text-xs overflow-x-auto" style={{ background: "#0a0418", border: "1px solid var(--line)" }}>
{`update public.profiles set is_admin = true where email = 'ban@gmail.com';`}
            </pre>
          </div>
        ) : (
          <>
            {msg && <p className="text-sm mb-3" style={{ color: "var(--cyan)" }}>{msg}</p>}
            <div className="card mb-4">
              <h2 className="text-lg font-bold mb-3">Yêu cầu nạp lượt — Chờ duyệt</h2>
              {pending.length === 0 ? (
                <p className="text-sm text-center py-4" style={{ color: "var(--sub)" }}>Không có yêu cầu nào chờ duyệt 🎉</p>
              ) : (
                pending.map((b) => (
                  <div key={b.id} className="flex justify-between items-center py-3 text-sm" style={{ borderBottom: "1px dashed var(--line)" }}>
                    <div>
                      {namesById[b.user_id]} · +{b.credits_requested} lượt · {b.amount_vnd.toLocaleString("vi-VN")}đ
                      <br />
                      <span style={{ color: "var(--sub)" }}>{b.note} — {new Date(b.created_at).toLocaleString("vi-VN")}</span>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => approve(b.id)} className="btn-ok btn-sm" style={{ border: "none", color: "#fff", borderRadius: 9, padding: "7px 14px", fontWeight: 700, cursor: "pointer" }}>Duyệt</button>
                      <button onClick={() => reject(b.id)} className="btn-danger btn-sm" style={{ border: "none", color: "#fff", borderRadius: 9, padding: "7px 14px", fontWeight: 700, cursor: "pointer" }}>Từ chối</button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="card mb-4">
              <h2 className="text-lg font-bold mb-3">Toàn bộ giao dịch</h2>
              <table>
                <thead><tr><th>User</th><th>Lượt</th><th>Tiền</th><th>Trạng thái</th><th>Thời gian</th></tr></thead>
                <tbody>
                  {allBills.slice(0, 50).map((b) => (
                    <tr key={b.id}>
                      <td>{namesById[b.user_id]}</td>
                      <td>{b.credits_requested}</td>
                      <td>{b.amount_vnd.toLocaleString("vi-VN")}đ</td>
                      <td><span className={`badge badge-${b.status}`}>{STATUS_LABEL[b.status]}</span></td>
                      <td>{new Date(b.created_at).toLocaleString("vi-VN")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="card">
              <h2 className="text-lg font-bold mb-3">Người dùng</h2>
              <table>
                <thead><tr><th>Tên</th><th>Email</th><th>Lượt</th><th>Admin</th><th></th></tr></thead>
                <tbody>
                  {users.map((u) => (
                    <tr key={u.id}>
                      <td>{u.full_name}</td>
                      <td>{u.email}</td>
                      <td>{u.credits}</td>
                      <td>{u.is_admin ? "✔" : ""}</td>
                      <td><button onClick={() => addCredits(u.id)} className="btn-outline btn-sm">+10 lượt</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </main>
    </>
  );
}
