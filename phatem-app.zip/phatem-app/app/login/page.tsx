"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError(error.message === "Invalid login credentials" ? "Sai email hoặc mật khẩu" : error.message);
      return;
    }
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <h1 className="text-2xl font-extrabold text-center mb-1 logo-gradient">⚡ PHÁT EM</h1>
      <p className="text-center text-sm mb-6" style={{ color: "var(--sub)" }}>
        Đăng nhập để tạo QR &amp; quản lý lượt
      </p>
      <form onSubmit={onSubmit} className="card">
        <label>Email</label>
        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ban@gmail.com" />
        <label>Mật khẩu</label>
        <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
        {error && <p className="text-sm mt-3" style={{ color: "var(--danger)" }}>{error}</p>}
        <button type="submit" className="btn w-full mt-5" disabled={loading}>
          {loading ? "Đang đăng nhập..." : "Đăng nhập"}
        </button>
      </form>
      <p className="text-center text-sm mt-4" style={{ color: "var(--sub)" }}>
        Chưa có tài khoản?{" "}
        <Link href="/register" style={{ color: "var(--cyan)" }}>
          Đăng ký ngay
        </Link>
      </p>
    </div>
  );
}
