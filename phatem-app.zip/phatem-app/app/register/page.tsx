"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function RegisterPage() {
  const router = useRouter();
  const supabase = createClient();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (password.length < 6) {
      setError("Mật khẩu cần tối thiểu 6 ký tự");
      return;
    }
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: name } },
    });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    if (data.session) {
      router.push("/dashboard");
      router.refresh();
    } else {
      setDone(true);
    }
  }

  if (done) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center">
        <h1 className="text-xl font-bold mb-3">Kiểm tra email 📩</h1>
        <p style={{ color: "var(--sub)" }}>
          Mình đã gửi link xác nhận tới <b>{email}</b>. Xác nhận xong quay lại{" "}
          <Link href="/login" style={{ color: "var(--cyan)" }}>
            đăng nhập
          </Link>
          .
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <h1 className="text-2xl font-extrabold text-center mb-1 logo-gradient">⚡ PHÁT EM</h1>
      <p className="text-center text-sm mb-6" style={{ color: "var(--sub)" }}>
        Tạo tài khoản mới — mặc định tặng 3 lượt
      </p>
      <form onSubmit={onSubmit} className="card">
        <label>Họ tên</label>
        <input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Nguyễn Văn A" />
        <label>Email</label>
        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ban@gmail.com" />
        <label>Mật khẩu</label>
        <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Tối thiểu 6 ký tự" />
        {error && <p className="text-sm mt-3" style={{ color: "var(--danger)" }}>{error}</p>}
        <button type="submit" className="btn w-full mt-5" disabled={loading}>
          {loading ? "Đang tạo..." : "Đăng ký"}
        </button>
      </form>
      <p className="text-center text-sm mt-4" style={{ color: "var(--sub)" }}>
        Đã có tài khoản?{" "}
        <Link href="/login" style={{ color: "var(--cyan)" }}>
          Đăng nhập
        </Link>
      </p>
    </div>
  );
}
