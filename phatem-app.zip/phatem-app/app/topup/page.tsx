"use client";
import { useEffect, useState, useCallback } from "react";
import NavBar from "@/components/NavBar";
import { createClient } from "@/lib/supabase/client";
import { COST_PER_CREDIT } from "@/lib/vietqr";

type Bill = {
  id: string;
  credits_requested: number;
  amount_vnd: number;
  status: "pending" | "approved" | "rejected";
  created_at: string;
};

const STATUS_LABEL: Record<string, string> = { pending: "Chờ duyệt", approved: "Đã duyệt", rejected: "Từ chối" };

export default function TopupPage() {
  const supabase = createClient();
  const [userId, setUserId] = useState<string | null>(null);
  const [credits, setCredits] = useState(0);
  const [isAdmin, setIsAdmin] = useState(false);
  const [wantCredits, setWantCredits] = useState(10);
  const [note, setNote] = useState("");
  const [bills, setBills] = useState<Bill[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const loadBills = useCallback(
    async (uid: string) => {
      const { data } = await supabase
        .from("bills")
        .select("id, credits_requested, amount_vnd, status, created_at")
        .eq("user_id", uid)
        .order("created_at", { ascending: false });
      setBills(data ?? []);
    },
    [supabase]
  );

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      setUserId(data.user.id);
      const { data: profile } = await supabase
        .from("profiles")
        .select("credits, is_admin")
        .eq("id", data.user.id)
        .single();
      setCredits(profile?.credits ?? 0);
      setIsAdmin(!!profile?.is_admin);
      loadBills(data.user.id);
    });
  }, [supabase, loadBills]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!userId) return;
    if (!note.trim()) {
      setMsg("Vui lòng nhập nội dung chuyển khoản để admin đối chiếu");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("bills").insert({
      user_id: userId,
      credits_requested: wantCredits,
      amount_vnd: wantCredits * COST_PER_CREDIT,
      note: note.trim(),
      status: "pending",
    });
    setSubmitting(false);
    if (error) {
      setMsg("Lỗi: " + error.message);
      return;
    }
    setMsg("Đã gửi yêu cầu — chờ admin duyệt");
    setNote("");
    loadBills(userId);
  }

  function copyText(t: string) {
    navigator.clipboard?.writeText(t);
    setMsg("Đã copy: " + t);
  }

  return (
    <>
      <NavBar initialCredits={credits} isAdmin={isAdmin} />
      <main className="max-w-4xl mx-auto px-4 pb-16">
        <div className="card mb-4">
          <h2 className="text-lg font-bold mb-3">Thông tin chuyển khoản nạp lượt</h2>
          {[
            ["Ngân hàng", "VPBank"],
            ["Số tài khoản", "0382238621"],
            ["Chủ tài khoản", "VÕ VĂN PHÁT EM"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between py-2 text-sm" style={{ borderBottom: "1px dashed var(--line)" }}>
              <span style={{ color: "var(--sub)" }}>{k}</span>
              <b className={k === "Số tài khoản" ? "cursor-pointer" : ""} onClick={() => k === "Số tài khoản" && copyText(v)}>
                {v}
                {k === "Số tài khoản" ? " 📋" : ""}
              </b>
            </div>
          ))}
        </div>

        <form onSubmit={submit} className="card mb-4">
          <h2 className="text-lg font-bold mb-1">Đăng ký nạp lượt</h2>
          <label>Số lượt muốn nạp</label>
          <input type="number" min={1} value={wantCredits} onChange={(e) => setWantCredits(Math.max(1, Number(e.target.value) || 1))} />
          <p className="text-xs mt-1" style={{ color: "var(--sub)" }}>Đơn giá: {COST_PER_CREDIT.toLocaleString("vi-VN")}đ / lượt</p>
          <div className="flex justify-between py-2 mt-2 text-sm">
            <span style={{ color: "var(--sub)" }}>Tổng tiền cần chuyển</span>
            <b style={{ color: "var(--pink)", fontFamily: "Orbitron" }}>{(wantCredits * COST_PER_CREDIT).toLocaleString("vi-VN")}đ</b>
          </div>
          <label>Nội dung chuyển khoản bạn đã dùng (để admin dò khớp)</label>
          <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="VD: NAP LUOT NGUYEN VAN A" />
          <p className="text-xs mt-1" style={{ color: "var(--sub)" }}>
            Bản này chưa hỗ trợ đính kèm ảnh bill — admin sẽ đối chiếu qua nội dung/số tiền trên sao kê.
          </p>
          {msg && <p className="text-sm mt-3" style={{ color: "var(--cyan)" }}>{msg}</p>}
          <button type="submit" className="btn mt-4" disabled={submitting}>
            {submitting ? "Đang gửi..." : "✅ Đã chuyển — Gửi yêu cầu duyệt"}
          </button>
        </form>

        <div className="card">
          <h2 className="text-lg font-bold mb-3">Lịch sử yêu cầu của bạn</h2>
          {bills.length === 0 ? (
            <p className="text-sm text-center py-4" style={{ color: "var(--sub)" }}>Chưa có yêu cầu nào</p>
          ) : (
            <table>
              <thead>
                <tr><th>Thời gian</th><th>Lượt</th><th>Số tiền</th><th>Trạng thái</th></tr>
              </thead>
              <tbody>
                {bills.map((b) => (
                  <tr key={b.id}>
                    <td>{new Date(b.created_at).toLocaleString("vi-VN")}</td>
                    <td>{b.credits_requested}</td>
                    <td>{b.amount_vnd.toLocaleString("vi-VN")}đ</td>
                    <td><span className={`badge badge-${b.status}`}>{STATUS_LABEL[b.status]}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </main>
    </>
  );
}
