"use client";
import { useEffect, useRef, useState } from "react";
import QRCode from "qrcode";
import html2canvas from "html2canvas";
import NavBar from "@/components/NavBar";
import { createClient } from "@/lib/supabase/client";
import { BANKS, TEMPLATES, buildVietQR } from "@/lib/vietqr";

export default function CreatePage() {
  const supabase = createClient();
  const [credits, setCredits] = useState<number | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [tpl, setTpl] = useState(0);
  const [bin, setBin] = useState(BANKS[0][0]);
  const [acc, setAcc] = useState("");
  const [accName, setAccName] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ payload: string; bankName: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const { data: profile } = await supabase
        .from("profiles")
        .select("credits, is_admin")
        .eq("id", data.user.id)
        .single();
      setCredits(profile?.credits ?? 0);
      setIsAdmin(!!profile?.is_admin);
    });
  }, [supabase]);

  useEffect(() => {
    if (result && canvasRef.current) {
      QRCode.toCanvas(canvasRef.current, result.payload, { width: 200, margin: 1 });
    }
  }, [result]);

  async function onGenerate(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!acc.trim() || !accName.trim()) {
      setError("Vui lòng nhập đủ số tài khoản và tên chủ tài khoản");
      return;
    }
    if (!credits || credits <= 0) {
      setError("Bạn đã hết lượt — hãy sang trang Nạp lượt");
      return;
    }
    setLoading(true);
    const amountDigits = amount.replace(/\D/g, "");
    const { data: remaining, error: rpcError } = await supabase.rpc("consume_credit", {
      p_bank_bin: bin,
      p_account: acc.trim(),
      p_name: accName.trim().toUpperCase(),
      p_amount: amountDigits ? Number(amountDigits) : null,
      p_template: tpl,
    });
    setLoading(false);
    if (rpcError) {
      setError(rpcError.message.includes("INSUFFICIENT_CREDITS") ? "Bạn đã hết lượt" : rpcError.message);
      return;
    }
    setCredits(remaining as number);
    const bankName = BANKS.find((b) => b[0] === bin)![1];
    const payload = buildVietQR({
      bin,
      account: acc.trim(),
      name: accName.trim(),
      amount: amountDigits || null,
      note: note.trim() || null,
    });
    setResult({ payload, bankName });
  }

  async function onDownload() {
    if (!cardRef.current) return;
    const canvas = await html2canvas(cardRef.current, { backgroundColor: null, scale: 2 });
    const url = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = `phatem-qr-${acc || "code"}.png`;
    a.click();
  }

  const bankName = BANKS.find((b) => b[0] === bin)?.[1] ?? "";

  return (
    <>
      <NavBar initialCredits={credits ?? 0} isAdmin={isAdmin} />
      <main className="max-w-4xl mx-auto px-4 pb-16">
        <div className="card mb-4">
          <h2 className="text-lg font-bold mb-3">1. Chọn mẫu QR</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {TEMPLATES.map((t) => (
              <div
                key={t.id}
                onClick={() => setTpl(t.id)}
                className="rounded-xl p-2 text-center cursor-pointer"
                style={{
                  border: tpl === t.id ? "2px solid var(--purple)" : "2px solid var(--line)",
                  boxShadow: tpl === t.id ? "0 0 16px rgba(168,85,247,.5)" : "none",
                  background: "#0a0418",
                }}
              >
                <div className={`h-20 rounded-lg mb-2 flex items-center justify-center text-xs font-bold text-white ${t.className}`}>
                  {t.name.toUpperCase()}
                </div>
                <div className="text-xs font-semibold" style={{ color: "var(--sub)" }}>{t.name}</div>
              </div>
            ))}
          </div>
        </div>

        <form onSubmit={onGenerate} className="card mb-4">
          <h2 className="text-lg font-bold mb-1">2. Thông tin chuyển khoản</h2>
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label>Ngân hàng</label>
              <select value={bin} onChange={(e) => setBin(e.target.value)}>
                {BANKS.map((b) => (
                  <option key={b[0]} value={b[0]}>{b[1]}</option>
                ))}
              </select>
            </div>
            <div>
              <label>Số tài khoản</label>
              <input value={acc} onChange={(e) => setAcc(e.target.value)} placeholder="0382238621" inputMode="numeric" />
            </div>
          </div>
          <label>Tên chủ tài khoản</label>
          <input value={accName} onChange={(e) => setAccName(e.target.value.toUpperCase())} placeholder="VO VAN A" />
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label>Số tiền (không bắt buộc)</label>
              <input value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Để trống nếu QR không cố định số tiền" inputMode="numeric" />
            </div>
            <div>
              <label>Nội dung (không bắt buộc)</label>
              <input value={note} onChange={(e) => setNote(e.target.value)} maxLength={25} placeholder="VD: chuyen tien thang 9" />
            </div>
          </div>
          <p className="text-xs mt-2" style={{ color: "var(--sub)" }}>
            Mã QR sinh theo chuẩn VietQR (EMV) — quét được bằng hầu hết app ngân hàng/MoMo tại Việt Nam.
          </p>
          {error && <p className="text-sm mt-3" style={{ color: "var(--danger)" }}>{error}</p>}
          <button type="submit" className="btn mt-4" disabled={loading || !credits}>
            {loading ? "Đang tạo..." : "⚡ TẠO QR (−1 lượt)"}
          </button>
          {!credits && <span className="text-xs ml-3" style={{ color: "var(--danger)" }}>Bạn đã hết lượt</span>}
        </form>

        {result && (
          <div className="card">
            <h2 className="text-lg font-bold mb-3">Kết quả</h2>
            <div className="flex justify-center my-4">
              <div ref={cardRef} className={`w-[340px] rounded-2xl p-6 relative text-white ${TEMPLATES[tpl].className}`}>
                <div className="absolute top-3 right-4 text-xs font-extrabold opacity-70" style={{ fontFamily: "Orbitron" }}>
                  PHÁT EM
                </div>
                <div className="bg-white rounded-xl p-2 w-[180px] mx-auto my-3">
                  <canvas ref={canvasRef} />
                </div>
                <div className="text-center mt-3">
                  <div className="font-extrabold text-base tracking-wide">{accName}</div>
                  <div className="acc-number font-bold text-xl mt-1 tracking-wider" style={{ fontFamily: "Orbitron" }}>{acc}</div>
                  <div className="text-xs opacity-85 mt-1">
                    {bankName}
                    {amount ? ` · ${Number(amount.replace(/\D/g, "")).toLocaleString("vi-VN")}đ` : ""}
                  </div>
                </div>
              </div>
            </div>
            <div className="text-center">
              <button onClick={onDownload} className="btn-ok" style={{ padding: "12px 22px", borderRadius: 12, border: "none", color: "#fff", fontWeight: 700, cursor: "pointer" }}>
                ⬇️ Tải ảnh QR
              </button>
            </div>
          </div>
        )}
      </main>
    </>
  );
}
